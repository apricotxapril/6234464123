
package lab7_2;

import java.util.Scanner;

public class MagicSquareTester {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter n : ");
        int input = sc.nextInt();
        while(input%2==0){
            System.out.print("Enter n : ");
            input = sc.nextInt();
        }
        MagicSquare test = new MagicSquare(input);
        
        System.out.println(test.toString());
    }
}
