
package lab7_2;

public class MagicSquare {

    private int n;
    private int[][] square;
    public MagicSquare(int a){
        n = a;
        int i = n-1;
        int j = n/2;
        square = new int[n][n];
        for(int k = 1;k <= n*n;k++){
            square[i][j] = k;
            i++;j++;
            if(i == n) i=0;
            if(j == n) j=0;
            if(square[i][j] != 0){
                i--;j--;
                if(i==-1) i=n-1;
                if(j==-1) j=n-1;
                i--;
            }
         
        }
    
    }
    
    public String toString(){
        String output = "";
        int m = String.valueOf(n*n).length();
        
        for(int i = 0;i<n;i++){
            for(int j = 0;j<n;j++){
                output += String.valueOf(square[i][j]);
                int len = String.valueOf(square[i][j]).length();
                for(int t = 0;t<=m-len;t++){
                    output += " ";
                
                }
                
            }
            output += "\n";    
        }
        return output;
    }
    
}
