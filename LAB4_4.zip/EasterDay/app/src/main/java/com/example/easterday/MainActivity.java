package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText y;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        y = (EditText)findViewById(R.id.editText1) ;


        Button send = (Button)findViewById(R.id.button1);
        send.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                String easter = MainActivity.Easterday(y) ;


                intent.putExtra("MyValue", easter);
                startActivity(intent);


            }
        });


    }


    public static String Easterday(EditText y){
        int num = Integer.parseInt(y.getText().toString()) ;
        int a = num%19 ;
        int b = num/100 ;
        int c = num%100 ;
        int d = b/4 ;
        int e = b%4 ;
        int g = ((8*b)+13)/25 ;
        int h = (((((19 * a) + b)-d)-g)+ 15)%30  ;
        int j = c/4 ;
        int k = c%4 ;
        int m = (a + (11 * h))/319 ;
        int r = ((2 * e) + 2 * j - k - h + m + 32)%7 ;
        int n = (h - m + r + 90)/25 ;
        int p = (h - m + r + n + 19)%32 ;

        String[] month={"January","February","March","April","May","June","July","August","September","October","November","December"} ;

        String easterdate = month[n-1]+" "+p ;

        return easterdate ;

    }
    }

