
package lab4_3;

public class TimeInterval {
    int h1;
    int m1;
    int h2;
    int m2;
    
    public TimeInterval(int start,int end) {
        h1 = start / 100;
        m1 = start % 100;
        h2 = end / 100;
        m2 = end % 100;
        
        if (m1 > m2) {
            m2 += 60;
            h2 -= 1;
        }
    }
    public int getHours() {
        int diffHour = h2 - h1;
        return diffHour;
    }
    public int getMinutes() {
        int diffMin = m2 - m1;
        return diffMin;
        
    }
    
}
