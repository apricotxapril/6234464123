
package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); 
        System.out.print("Enter start time : ");
        int start = input.nextInt();
        System.out.print("Enter end time : ");
        int end = input.nextInt();
        
        TimeInterval test = new TimeInterval(start,end);
        System.out.println( test.getHours() +" hours " + test.getMinutes() +" minutes" );
    }
       
}
