/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Supapen Kaewlee
 */
public class TaylorTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        expo exp = new expo(7, 1);
        exp.printValue();
        sine s = new sine(7, Math.PI/4);
        s.printValue();
        cosine cs = new cosine(7, 1);
        cs.printValue();
        
        
    }
    
}
