/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Supapen Kaewlee
 */
public class cosine extends Taylor{
    
    public cosine(int k,double x){
        this.setIter(k);
        this.setValue(x);
    }

    @Override
    public void printValue() {
        System.out.println("Value from Math.cos() is "+Math.cos(this.getValue()));
        System.out.println("Approximated value is "+this.getApprox());
    }

    @Override
    public double getApprox() {
        double sum = 0;
        for(int n = 0;n <= this.getIter();n++){
            sum += Math.pow(-1,n)*(Math.pow(this.getValue(),2*n))/this.factorial(2*n);
        }
        return sum;
    }
    
}
