package com.example.lab6_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    EditText your_guess;
    int num ;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Random n = new Random();
        num = n.nextInt(100)+1;


        your_guess = (EditText)findViewById(R.id.editText1) ;
        text = (TextView)findViewById(R.id.textView2) ;


        Button guess = (Button)findViewById(R.id.button2);
        guess.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, Main3Activity.class);

                if(Guess_num()){
                    startActivity(intent);
                }
                else{
                    your_guess.setText("");
                }

            }
        });


    }

    public boolean Guess_num(){
        int your_num = Integer.parseInt(your_guess.getText().toString()) ;
        if(your_num>num){
            text.setText("Your guess is too high");
        }
        else if(your_num<num){
            text.setText("Your guess is too low");
        }
        else if(your_num==num){
            return true;
        }
        return false;

    }

}
