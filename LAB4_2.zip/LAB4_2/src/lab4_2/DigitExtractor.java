
package lab4_2;

public class DigitExtractor {
    private int num;
    public DigitExtractor(int anInteger) {
        num = anInteger;
}
    public int nextDigit() {
        int n = num%10;
        num = num/10;
        return n;
}
        
}
