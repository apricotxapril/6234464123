/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

/**
 *
 * @author apricotxapril
 */
public class FileMatch {
    
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<AccountRecord> ac = new ArrayList<AccountRecord>();
        ArrayList<TransactionRecord> tr = new ArrayList<TransactionRecord>();
    
        File master = new File("master.txt");
        try(Scanner in = new Scanner(master)){
            while(in.hasNextLine()){
                int accNo = in.nextInt();
                String name = in.next()+" "+in.next();
                double balance = in.nextDouble();
                ac.add(new AccountRecord(accNo,name,balance));
            }
            File trans = new File("trans.txt");
            Scanner in2 = new Scanner(trans);
            while(in2.hasNextInt()){
                int accNo = in2.nextInt();
                double amountTrans = in2.nextDouble();
                tr.add(new TransactionRecord(accNo,amountTrans));
            }
            in2.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        
        for(int i = 0;i < ac.size();i++){
            for(int j = 0;j<tr.size();j++){
                if(ac.get(i).getAcctNo()==tr.get(j).getaccountnumber()){
                    ac.get(i).combine(tr.get(j));
                }
            }
        }
        
        //System.out.print(ac+"\n"+tr);
          
        try(RandomAccessFile f = new RandomAccessFile("newMaster.dat","rw");){
            for(int i = 0;i<ac.size();i++){
                String name = ac.get(i).getName();
                while(name.length()<=30){
                    name += " ";
                }
                String text = ac.get(i).getAcctNo()+" "+name+" "+ac.get(i).getBalance()+" "+ac.get(i).getTransCnt()+"\n";
                f.writeBytes(text);
                /*f.writeInt(ac.get(i).getAcctNo());
                f.writeChars(" "+name+" ");
                f.writeDouble(ac.get(i).getBalance());
                f.writeChars(" ");
                f.writeInt(ac.get(i).getTransCnt());*/
                //System.out.println(text);
            }
            f.seek(0);
            
            int line =0,trans = 0;
            double balance = 0;
            String data = f.readLine();
            
            while(data!=null){
                line++;
                balance += Double.parseDouble(data.substring(35,data.length()-2));
                if(data.substring(data.length()-1).equals("0")){
                    trans++;
                }
                data = f.readLine();
            }
            
            System.out.println("Total Account Record : "+line);
            System.out.println("Total balance : "+balance);
            System.out.println("No transaction : "+trans+" account.");
            
        }
        catch(Exception e){
            System.out.println(e);
        }
        
    }
}
