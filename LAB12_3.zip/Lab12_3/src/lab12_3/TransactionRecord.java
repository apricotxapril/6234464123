/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author apricotxapril
 */
public class TransactionRecord {
    
    private int accountnumber;
    private double amountOfTransaction;
    
    public TransactionRecord(int accountnumber,double amountOfTransaction){
        this.accountnumber = accountnumber;
        this.amountOfTransaction = amountOfTransaction;
    }
    
    public int getaccountnumber(){
        return accountnumber;
    }
    
    public double getamountOfTransaction(){
        return amountOfTransaction;
    }
    
    public void setaccountnumber(){
        this.accountnumber = accountnumber;
    }
    
    public void setamountOfTransaction(){
        this.amountOfTransaction = amountOfTransaction;
    }

    /**
     * @param args the command line arguments
     */
    
    
}
