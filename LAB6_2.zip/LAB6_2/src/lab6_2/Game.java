
package lab6_2;

import java.util.Scanner; 
import java.util.Random; 

public class Game {
    
    private int personScore;
    private int computerScore;
    
    public Game() {
        personScore = 0;
        computerScore = 0;
    }
    
    private String getText(int choice) {
        String stringReturn = "";
        switch (choice) {
            case 0: stringReturn = "ROCK"; break;
            case 1: stringReturn = "PAPER"; break;
            case 2: stringReturn = "SCISSORS"; break;
            default: stringReturn = ""; break;
        }
        return stringReturn;
    }
    
    private static boolean isInteger(String input) {
        try {
            Integer.parseInt(input);
            return true;
        }
        catch(Exception e) { 
            return false;
        }
    } 
    
    public void play() {
        
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        
        String playerInputString;
        int playerInput;
        int computerInput;
        boolean ended = false;
        
        while (!ended) {
            
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            playerInputString = scanner.nextLine();
            
            if (isInteger(playerInputString)) {
                
                playerInput = Integer.parseInt(playerInputString);
                
                    if ( playerInput == 0 || playerInput == 1 || playerInput == 2 ) {
                    System.out.println("You enter: " + getText(playerInput));
                    computerInput = random.nextInt(3);
                    System.out.println("Computer: " + getText(computerInput));

                    if ( (playerInput > computerInput) || (playerInput == 0 && computerInput == 2) ) {
                        personScore = personScore + 1;
                        System.out.println("You win!");
                    }

                    else if ( (playerInput < computerInput) || (playerInput == 2 && computerInput == 0) ) {
                        computerScore = computerScore + 1;
                        System.out.println("You lose!");
                    }

                    else {
                        System.out.println("It's a tie.");
                    }

                    if (Math.abs(personScore - computerScore) == 2) {
                        ended = true;
                    }

                }
                    
            }

        }
        
        //print result
        System.out.println("----------------------------------------");
        if (personScore > computerScore) {
            System.out.println("Congrats! You win.");
        }
        else {
            System.out.println("Too bad! You lose.");
        }
        System.out.println("User score: " + personScore);
        System.out.println("Computer score: " + computerScore);
        
        personScore = 0;
        computerScore = 0;
        
    }
     
}
