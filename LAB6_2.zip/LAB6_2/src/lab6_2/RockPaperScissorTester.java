
package lab6_2;

/**
 *
 * @author HOME PC
 */
public class RockPaperScissorTester {
    
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }
}
