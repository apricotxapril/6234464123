
package lab3_3;

public class CashRegister {
    private final double taxRate;
    private double purchase;
    private double taxablePurchase;
    private double payment;
	
    public CashRegister() {
        taxRate = 7;
        purchase = 0;
        payment = 0;
    }
    public void recordPurchase(double amount) {
        purchase = purchase + amount;
    }
    public void recordTaxablePurchase(double amount) {
        amount = amount + amount*(taxRate / 100);
        taxablePurchase = taxablePurchase + amount;
    }
    public double getTotalTax() {
        return taxablePurchase;
    }
    public void enterPayment(double amount) {
        payment = payment + amount;
    }
    public double giveChange() {
        double change = payment - purchase - taxablePurchase;
        purchase = 0;
        payment = 0;
        return change;
    }
}
