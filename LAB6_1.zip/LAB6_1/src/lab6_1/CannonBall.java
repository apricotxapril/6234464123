
package lab6_1;

public class CannonBall {

    private double initV; //initial velocity
    private double simS; //distance calculated from simulation
    private double simT; //time used in simulation method
    public static final double g = 9.81;
	
    public CannonBall(double velocity) {
	initV = velocity;
    }

    //calculate distance every sec 1 to 10
    //deltaT = 0.01 ref. from lab sheet
    public void simulatedFlight() {
        final double DELTA_T = 0.01;
        double deltaS = 0;
        double v = initV;
        int time = 0;
        int second = 0;
        
        while (v > 0) {
            
            deltaS = v*DELTA_T;
            simS = simS + deltaS;
            v = v - (g*DELTA_T);
            simT = simT + 0.01;
            time = time + 1;
            
            if (time%100 == 0) {
                second = second + 1;
                System.out.printf("Distance on %d sec: %.3f", second, simS);
                System.out.println();
            }

        }
        
        System.out.printf("Final distance: %.3f Total time: %.2f", simS, simT);
        System.out.println();
    }	
    
    //calculate distance ball move for t secs
    //s = -0.5*g*t**2 + initV*t
    public double calculusFlight(double t) {      
        return (-0.5) * g * Math.pow(t,2) + initV * t;
    }
    
    //return total time since ball to air 'till to ground 
    public double getSimulatedTime() {
        return simT;
    }
    
    //return final distance (ball reach ground)
    public double getSimulatedDistance() {
        return simS;
    }
    
}

