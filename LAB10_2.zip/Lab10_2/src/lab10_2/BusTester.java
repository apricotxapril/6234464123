/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;

/**
 *
 * @author apricotxapril
 */
public class BusTester {
    
    public static void main(String[] args) {

        ArrayList<Bus> array = new ArrayList<Bus>();
        array.add(new Hybrid(150,1,600,45,1.2));
        array.add(new CNGBus(200,2,50,1));
        
        for(int i = 0;i < array.size();i++){
            System.out.println("ID: "+array.get(i).getID());
            if(array.get(i) instanceof CNGBus){
                CNGBus bus = (CNGBus) array.get(i);
                System.out.println("Emission Tier: "+bus.getEmissionTier());
            }
            else if(array.get(i) instanceof Hybrid){
                Hybrid bus = (Hybrid) array.get(i);
                System.out.println("Emission Tier: "+bus.getEmissionTier());
            }
            System.out.println("Accel: "+array.get(i).getAccel());
        }
    }
    
}
