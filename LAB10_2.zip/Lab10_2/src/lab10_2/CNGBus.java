/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * @author apricotxapril
 */
public class CNGBus extends Bus implements LiquidFuel{
    
    private double range;
    private int emissionTier;
    
    public CNGBus(double range,int emissionTier,int capacity,double cost){
        super(capacity,cost);
        this.range = range;
        this.emissionTier = emissionTier;
    }
    
    public double getAccel(){
        return 3.0;
    }
    
    public double getRange(){
        return range;
    }
    
    public int getEmissionTier(){
        return emissionTier;
    }
}
