
package lab3_2;

public class LetterPrinter {
    
     public static void main(String[] args) {
        Letter test = new Letter("Jade", "Clarissa");
        test.addLine("We must find Simon quickly.");
        test.addLine("He might be in danger.");
        System.out.println(test.getText());
    }
}
