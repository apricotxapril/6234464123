
package lab3_2;

public class Letter {
    private final String from;
    private final String to;
    private String text;
    
    public Letter(String from, String to) {
        this.from = from;
        this.to = to;
        this.text = "";
    }
    public void addLine(String line) {
        this.text += String.format("%s\n", line);
    }
    public String getText() {
        return String.format("Dear %s\n\n%s\nSincerely,\n\n%s", this.from, this.text, this.to);
    }
}
