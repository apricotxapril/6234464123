/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

import java.util.ArrayList;
/**
 *
 * @author Supapen Kaewlee
 */
public class ChoiceQuestion extends Question{
    
    ArrayList<String> choices = new ArrayList<String>() ;
    
    public ChoiceQuestion(String text){
        this.text = text;
    }
    
    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if(correct==true){
            this.setAnswer(choice);
        }
        
    }
    
    public boolean checkAnswer(String response){
        
        int a = Integer.parseInt(response);
        String b = choices.get(a-1);
        
        if(b.equals(this.getAnswer())){
            return true;
        }
        return false;
    }
    
    public void display(){
        System.out.println(text);
        int i = 1;
        for(String s : choices){
            System.out.println(i+":"+s);
        i++;}
    }
    
}