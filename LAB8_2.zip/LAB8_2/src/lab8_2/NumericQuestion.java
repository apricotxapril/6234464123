/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author Supapen Kaewlee
 */
public class NumericQuestion extends Question{
    
    public NumericQuestion(String text){
        this.text = text;
    }
    
    public boolean checkAnswer(String response){
        if(response.equalsIgnoreCase(answer)){
            return true;
        }
        return false;
    }
    
}
