
package lab7_1;

import java.util.ArrayList;

public class Purse 
{
    private ArrayList<String> coins = new ArrayList<String>();
	private String[] coinNames = {"PENNY", "QUARTER", "NICKEL", "DIME"};
	private boolean isValid(String coinName) {
		for(int i = 0; i < coinNames.length; i++) {
			if (coinName.equalsIgnoreCase(coinNames[i])) {
				return true;
			}
		}
		return false;
	}
	public void addCoin(String coinName) {
		if (isValid(coinName)) {
			coins.add(coinName);
		} else {
			System.err.println("Invalid coin: " + coinName);
		}
	}
	public String toString() {
		return "Purse: " + coins;
	}

	public void reverse() {
		ArrayList<String> coins2 = new ArrayList<String>();
		for(int i = coins.size() - 1; 0 <= i; i--) {
			coins2.add(coins.get(i));
		}
		coins = coins2;
	}
	public void transfer(Purse other) {
		other.coins.addAll(coins);
		coins.clear();
	}
	public boolean sameContents(Purse other) {
		if (coins.size() != other.coins.size()) {
			return false;
		}
		for(int i = 0; i < coins.size(); i++) {
			if (!coins.get(i).equalsIgnoreCase(other.coins.get(i))) {
				return false;
			}
		}
		return true;
	}
	public boolean sameCoins(Purse other) {
		if (coins.size() != other.coins.size()) {
			return false;
		}
		for(int i = 0; i < coins.size(); i++) {
			String coin = coins.get(i);
			if (other.numCoins(coin) != numCoins(coin)) {
				return false;
			}
		}
		return true;
	}
	// used by sameCoins
	private int numCoins(String coin) {
		int result = 0;
		for(String next: coins) {
			if (next.equalsIgnoreCase(coin)) {
				result++;
			}
		}
		return result;
	}
        
}
