
package lab7_1;

public class PurseTester {
    
    public static void main(String[] args) {
        
        Purse p1 = new Purse();
        
	p1.addCoin("Dime");
	p1.addCoin("Quarter");
	System.out.println(p1); // Purse[dime, quarter]
	p1.reverse();
	System.out.println(p1); // Purse[quarter, dime]

	Purse p2 = new Purse(); //blank purse
	p1.transfer(p2); 
	System.out.println(p1); // Purse[]
	System.out.println(p2); // Purse[quarter, dime]
	p1.addCoin("Dime");
	p1.addCoin("Quarter");
	System.out.println(p1); // Purse[Dime, Quarter]
	System.out.println(p1.sameContents(p2)); // false
	System.out.println(p1.sameCoins(p2)); // true
	p1.addCoin("Quarter");
	System.out.println(p1); // Purse[Dime, Quarter, Quarter]
	System.out.println(p1.sameCoins(p2)); // false
        
    }
    
}
