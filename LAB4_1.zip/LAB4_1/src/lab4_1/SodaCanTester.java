
package lab4_1;

import java.util.Scanner;

public class SodaCanTester {
    public static void main(String[] args)
    {
       Scanner input = new Scanner(System.in); // Create a Scanner object
       System.out.print("Enter height :");
       double height = input.nextDouble();  // Read user input
       System.out.print("Enter diameter :");  // Output user input
       double diameter = input.nextDouble();
       
       SodaCan test = new SodaCan(height,diameter);
       System.out.printf("Volume: %.2f \n",test.getVolume()); 
       System.out.printf("Surface Area: %.2f \n",test.getSurfaceArea());
    }
}