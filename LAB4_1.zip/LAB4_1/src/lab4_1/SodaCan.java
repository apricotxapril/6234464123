
package lab4_1;

public class SodaCan {
    private double height;
    private double diameter;

    //volume=pi*d/2**2*h
    public SodaCan(double h,double d) {
        height = h;
        diameter = d;  
    }
    public double getVolume() {
        return ( Math.PI * Math.pow(diameter/2, 2) * height);        
    }
    public double getSurfaceArea() {
        return ( 2 * Math.PI * diameter/2 * height + (2 * Math.PI * Math.pow(diameter/2, 2)) );
    }
}
