
package lab3_1;

public class InsectPopulation {
    private double population;
    
    public InsectPopulation(double num) {
        population = num;
    }
    public void breed() {
        population = population*2;
    }
    public void spray() {
        population = population*0.9;
    }
    public double getNumInsect() {
        return population;
    }
    
}