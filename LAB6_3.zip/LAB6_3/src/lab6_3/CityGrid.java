
package lab6_3;

import java.util.Random;

public class CityGrid {


    private int xCoor;
    private int yCoor;
    private final int gridSize;
    private final int xLength;
    private final int yLength;
    
    public CityGrid(int x, int y) {
        xLength = x;
        yLength = y;
        gridSize = x*y;
        xCoor = x/2;
        yCoor = y/2;
    }
    
    public void walk() {
        Random randomWalk = new Random();
        int direction = randomWalk.nextInt(4);
        switch (direction) {
            case 0: xCoor++; break;
            case 1: xCoor--; break;
            case 2: yCoor--; break;
            case 3: yCoor++; break;
        }
    }
    
    public boolean isInCity() {
        boolean inCity = true;
        if (yCoor < 0 || yCoor > yLength || xCoor < 0 || xCoor > xLength) {
            inCity = false;
        }
        return inCity;
    }
    
    public void reset() {
        xCoor = xLength/2;
        yCoor = yLength/2;
    }
    
}
