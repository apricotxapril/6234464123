
package lab6_3;


public class CityGridTester {
    
    public static void main(String[] args) {
        
        CityGrid test = new CityGrid(10,10);
        int step = 0;
        int totalSteps = 0;
        int maxSteps = 0;
        
        for (int i = 0; i < 10000; i++) {
            
            while (test.isInCity() && step < 1000) { 
                test.walk();
                step++;
            }
            
            totalSteps = totalSteps + step;
            
            if (maxSteps < step) {
                maxSteps = step;
            }
            
            step = 0;
            test.reset();
            
        }
        
        System.out.printf("Average number of steps that a person can take and is still in the city: %.02f", totalSteps/10000.0);
        System.out.println();
        System.out.printf("Maximum number of steps that a person can take and is still in the city: %d", maxSteps);
        System.out.println();

    }
}
