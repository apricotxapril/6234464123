package lab2_3;

import java.util.Calendar; 
import java.util.GregorianCalendar; 

public class gregorian {
    
    GregorianCalendar cal = new GregorianCalendar();
    GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.APRIL,27);

    public void PrG(GregorianCalendar date){
        int weekday = date.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth = date.get(Calendar.DAY_OF_MONTH); 
        int month = date.get(Calendar.MONTH);
        int year = date.get(Calendar.YEAR);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
    
    }
    public static void main(String[] args) {
        gregorian cal2 = new gregorian();
        cal2.cal.add(Calendar.DAY_OF_MONTH, 100);
        cal2.myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        cal2.PrG(cal2.cal);
        cal2.PrG(cal2.myBirthday);

    }
    
}
