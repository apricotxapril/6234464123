/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author apricotxapril
 */
public class SelfCheckOut implements SimpleQueue{
    private ArrayList<Product> ProductList = new ArrayList<Product>();
    private double amount;
    
    public void enqueue(Object o){
        if(o instanceof Product){
            Product p = (Product) o;
            System.out.println(p.getName()+" is added in queue");
            ProductList.add(p);}
    }
    public void dequeue(){
        Product p = ProductList.get(0);
        ProductList.remove(0);
        amount += p.getPrice();
    }
    
    public double getAmount(){
        return amount;
    }
}
